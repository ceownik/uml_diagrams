package com.umlet.element.activity;

public enum Direction {
	TOP, LEFT, RIGHT, BOTTOM;
}
