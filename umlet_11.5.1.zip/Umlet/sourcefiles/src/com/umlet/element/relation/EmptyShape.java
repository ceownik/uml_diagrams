package com.umlet.element.relation;

import java.awt.Rectangle;

@SuppressWarnings("serial")
public class EmptyShape extends Rectangle {
	public EmptyShape(int fontsize) {
		super(0, 0, fontsize, fontsize);
	}
}
