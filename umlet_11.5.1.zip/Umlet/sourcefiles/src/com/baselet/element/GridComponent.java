package com.baselet.element;

import javax.swing.JComponent;

public abstract class GridComponent extends JComponent {

	private static final long serialVersionUID = 1L;

	public abstract GridElement getGridElement();
}
