package com.baselet.gui.listener;

import com.baselet.diagram.DiagramHandler;

public class CustomPreviewListener extends DiagramListener {

	public CustomPreviewListener(DiagramHandler handler) {
		super(handler);
	}
}
